/**
 * Mezzo extension popup: says what's open, in one of four states
 * (lib/popup-state.js): no Mezzo tab; the Mezzo tab; the Companion; the
 * Companion monitoring. The tab is found by URL (lib/mezzo-tabs.js); the
 * Companion's state comes from the tab itself, through its page bridge
 * (content-scripts/mezzo-page-bridge.js), asked when the popup opens and
 * updated live while it's open.
 *
 * "Open Mezzo" opens Mezzo in its own window (background.js). "Go to Mezzo
 * tab" focuses the existing tab and its window, restoring it if minimized;
 * it never opens, navigates or reloads anything. The popup never tries to
 * open or focus the Companion (see lib/popup-state.js).
 */

import * as mezzoTabs from '../lib/mezzo-tabs.js';
import * as mezzoUrl from '../lib/mezzo-url.js';
import { POPUP_STATES, popupStateFor, askTabState } from '../lib/popup-state.js';

/** The screen the popup is on (available area), so Mezzo opens fully on it. */
function availableScreen(doc) {
  const s = doc.defaultView?.screen;
  if (!s || !Number.isFinite(s.availWidth)) return null;
  return { left: s.availLeft ?? 0, top: s.availTop ?? 0, width: s.availWidth, height: s.availHeight };
}

/** Renders one of POPUP_STATES' keys. */
export function renderPopup(doc, stateKey) {
  const state = POPUP_STATES[stateKey];
  doc.querySelector('.popup').dataset.state = stateKey;

  const chip = doc.querySelector('.status-chip');
  chip.hidden = !state.chip;
  if (state.chip) {
    chip.dataset.tone = state.chip.tone;
    chip.dataset.dot = state.chip.dot;
    chip.querySelector('.status-label').textContent = state.chip.label;
  }

  doc.querySelector('.lede').textContent = state.body;

  const button = doc.getElementById('btn-popup-action');
  button.textContent = state.button.label;
  button.className = state.button.kind === 'primary' ? 'btn-primary' : 'btn-outline';
  button.dataset.action = state.button.action;

  const note = doc.querySelector('.note');
  note.hidden = !state.note;
  note.replaceChildren();
  state.note?.forEach((line, i) => {
    if (i) note.append(doc.createElement('br'));
    note.append(line);
  });
}

export async function initPopup(doc = document, { tabs = mezzoTabs, chromeApi = globalThis.chrome, closePopup = () => window.close(), urls = mezzoUrl, timeoutMs } = {}) {
  const openMezzo = () => chromeApi.runtime.sendMessage({ type: 'OPEN_MEZZO', focused: true, screen: availableScreen(doc) });

  const tab = await tabs.findMezzoTab(chromeApi);
  const status = tab ? await askTabState(chromeApi, tab.id, timeoutMs) : null;
  renderPopup(doc, popupStateFor({ tabOpen: !!tab, ...(status ?? { companionOpen: false, monitoring: false }) }));

  // The tab reports changes while the popup is open (the Companion opened
  // or closed, monitoring started or stopped).
  if (tab) {
    chromeApi.runtime.onMessage?.addListener?.((message, sender) => {
      if (message?.type !== 'MEZZO_STATE' || sender?.tab?.id !== tab.id) return;
      renderPopup(doc, popupStateFor({ tabOpen: true, ...message.state }));
    });
  }

  doc.getElementById('btn-popup-action').addEventListener('click', async (event) => {
    if (event.currentTarget.dataset.action === 'open') {
      // An explicit click on the toolbar popup: bring Mezzo to the front.
      openMezzo();
      closePopup();
      return;
    }
    // "Go to Mezzo tab": the background does the switch. Focusing a window
    // closes this popup, which used to end the switch halfway (the window
    // focused, the tab never activated) when Mezzo shared the meeting's
    // window. The background finds the tab again, and opens Mezzo if it
    // has closed in the meantime.
    chromeApi.runtime.sendMessage({ type: 'FOCUS_MEZZO_TAB', screen: availableScreen(doc) });
    closePopup();
  });

  doc.getElementById('link-privacy').addEventListener('click', (event) => {
    event.preventDefault();
    urls.getBaseUrl(chromeApi).then((base) => {
      chromeApi.tabs.create({ url: `${base}/privacy.html` });
      closePopup();
    });
  });
}

if (globalThis.chrome?.runtime?.id) initPopup();
